module.exports = {
  bracketSpacing: true,
  semi: false,
  singleQuote: true,
  trailingComma: 'none'
}
